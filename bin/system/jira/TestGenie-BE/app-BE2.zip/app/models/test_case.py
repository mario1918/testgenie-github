from pydantic import BaseModel, Field
from typing import Any, Dict, Optional, List
from datetime import datetime
from enum import Enum

class ComponentEnum(str, Enum):
    ALERT = "Alert"
    ADMIN = "Admin"
    BOM = "BOM"

class StatusEnum(str, Enum):
    TODO = "To Do"
    IN_PROGRESS = "In Progress"
    DONE = "Done"

class PriorityEnum(str, Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"

class CreateTestCaseBody(BaseModel):
    project_key: str = Field("SE2", description="Project key")
    summary: str = Field(..., description="Summary of the test case")
    description: Optional[str] = Field(None, description="Description of the test case")
    components: List[str] = Field(default_factory=list, description="List of component names")
    related_issues: List[str] = Field(default_factory=list, description="List of related issue keys")
    sprint_id: Optional[int] = Field(None, description="Sprint ID")

class TestCaseBase(BaseModel):
    summary: str = Field(..., min_length=1, max_length=255, description="Test case summary")
    description: Optional[str] = Field(None, max_length=1000, description="Test case description")
    steps: Optional[str] = Field(None, description="Test execution steps")
    component: ComponentEnum = Field(..., description="Component being tested")
    sprint: Optional[str] = Field(None, description="Sprint assignment")
    expected_result: Optional[str] = Field(None, description="Expected test result")
    related_task: Optional[str] = Field(None, description="Related Jira task")

class TestCaseCreate(TestCaseBase):
    pass

class TestCaseUpdate(BaseModel):
    summary: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = Field(None, max_length=1000)
    steps: Optional[str] = None
    component: Optional[ComponentEnum] = None
    sprint: Optional[str] = None
    status: Optional[StatusEnum] = None
    priority: Optional[PriorityEnum] = None
    expected_result: Optional[str] = None
    related_task: Optional[str] = None

class TestCase(TestCaseBase):
    id: str = Field(..., description="Test case ID")
    status: StatusEnum = Field(default=StatusEnum.TODO, description="Test case status")
    priority: PriorityEnum = Field(default=PriorityEnum.MEDIUM, description="Test case priority")
    created: datetime = Field(default_factory=datetime.now, description="Creation timestamp")
    created_by: str = Field(default="System", description="Creator name")

    class Config:
        from_attributes = True

class TestCaseResponse(BaseModel):
    test_cases: List[TestCase]
    total: int
    page: int
    size: int

class BulkActionRequest(BaseModel):
    test_case_ids: List[str] = Field(..., description="List of test case IDs")
    action: str = Field(..., description="Action to perform")
    
class BulkActionResponse(BaseModel):
    success: bool
    message: str
    affected_count: int

class ExecutionStatusIn(BaseModel):
    id: Optional[int] = Field(None, description="Zephyr execution status id (e.g., 1=PASS, 2=FAIL, -1=UNEXECUTED)")

class CreateExecutionRequest(BaseModel):
    issue_id: str = Field(..., description="Jira issueId (numeric) of the Test")
    cycle_id: Optional[int] = Field(None, description="Zephyr cycle id")
    version_id: Optional[int] = Field(None, description="Jira version id (for context)")
    execution_status: Optional[ExecutionStatusIn] = Field(None, description="Optional initial status by id")

class CreateExecutionResponse(BaseModel):
    issue_id: str
    project_id: int
    cycle_id: Optional[int] = None
    version_id: Optional[int] = None
    execution_id: Optional[str] = None
    created: bool = False
    status_updated: bool = False

class FullCreateBody(BaseModel):
    summary: str
    description: Optional[str] = None
    components: Optional[List[str]] = None
    related_issues: Optional[List[str]] = None
    sprint_id: Optional[int] = None

    steps: Optional[List[Dict[str, Optional[str]]]] = None  # [{step,data,result}]

    version_id: Optional[int] = None
    cycle_id: Optional[int] = None

    execution_status: Optional[Dict[str, Any]] = None  # {"id":1} or {"name":"PASS"}
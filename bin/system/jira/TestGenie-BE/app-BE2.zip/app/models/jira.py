from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime

class JiraProject(BaseModel):
    id: str
    key: str
    name: str
    description: Optional[str] = None

class JiraSprint(BaseModel):
    id: int
    name: str
    state: str  # active, closed, future
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    complete_date: Optional[datetime] = None
    board_id: int

class JiraBoard(BaseModel):
    id: int
    name: str
    type: str
    project_key: str

class JiraIssue(BaseModel):
    id: str
    key: str
    summary: str
    description: Optional[str] = None
    issue_type: str
    status: str
    priority: str
    assignee: Optional[str] = None
    reporter: str
    created: datetime
    updated: datetime
    components: List[str] = Field(default_factory=list)
    sprint: Optional[str] = None 
    first_linked_issue: Optional[str] = None

class SprintResponse(BaseModel):
    sprints: List[JiraSprint]
    total: int

class ProjectResponse(BaseModel):
    projects: List[JiraProject]
    total: int


class UpdateTestCaseRequest(BaseModel):
    summary: Optional[str] = None
    description: Optional[str] = None
    component: Optional[str] = None
    sprint: Optional[str] = None
    status: Optional[str] = None
    priority: Optional[str] = None
    related_task: Optional[str] = Field(default=None, alias="relatedTask")  # accept camelCase
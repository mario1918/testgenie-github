from fastapi import APIRouter, HTTPException, Path, Query
from typing import Dict, List, Optional, Any
from app.models.jira import JiraSprint, JiraProject, JiraBoard, JiraIssue, SprintResponse, ProjectResponse, UpdateTestCaseRequest
from app.models.test_case import CreateTestCaseBody
from app.services.jira_service import jira_service
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/jira", tags=["jira"])

def _parse_csv(value: Optional[str]) -> List[str]:
    """Split comma-separated input into a clean list (strip, drop empties)."""
    if not value:
        return []
    return [v.strip() for v in value.split(",") if v and v.strip()]

def _jql_quote_list(values: List[str]) -> str:
    """Return a JQL-ready quoted list: "A","B","C" (already _quote()'d)."""
    return ",".join([f'"{_quote(v)}"' for v in values])

def _assignee_or_reporter_filter(field: str,
                                 csv_value: Optional[str],
                                 include_current_user: Optional[bool]) -> Optional[str]:
    """
    Build a JQL clause for assignee/reporter from a CSV list plus optional currentUser().
    Supports “Unassigned” to mean IS EMPTY, combining with others via OR.
    Examples:
      - field = "assignee"
      - csv_value = "Alice, Bob, Unassigned"
      - include_current_user = True
    Result:
      (assignee IN ("Alice","Bob") OR assignee = currentUser() OR assignee IS EMPTY)
    """
    names = _parse_csv(csv_value)

    has_unassigned = any(n.lower() == "unassigned" for n in names)
    names = [n for n in names if n and n.lower() != "unassigned"]

    parts: List[str] = []

    # IN ("A","B") when multiple; use '=' when single for a slightly simpler JQL
    if names:
        if len(names) == 1:
            parts.append(f'{field} = "{_quote(names[0])}"')
        else:
            parts.append(f'{field} IN ({_jql_quote_list(names)})')

    # currentUser()
    if include_current_user is True:
        # When combined with IN, keep as an OR
        parts.append(f"{field} = currentUser()")

    # Unassigned
    if has_unassigned:
        parts.append(f"{field} IS EMPTY")

    if not parts:
        return None
    if len(parts) == 1:
        return parts[0]
    return "(" + " OR ".join(parts) + ")"

def _quote(val: str) -> str:
    # Basic safety: escape inner quotes; strip dangerous semicolons
    return val.replace('"', r'\"').replace(";", "")

def _is_int(s: str) -> bool:
    try:
        int(s)
        return True
    except:
        return False

def _csv_to_list(value: Optional[str]) -> Optional[List[str]]:
    """Turn a comma-separated string into a list, or None."""
    if not value:
        return None
    return [v.strip() for v in value.split(",") if v.strip()]

@router.get("/projects", response_model=ProjectResponse)
async def get_projects():
    """Get all accessible Jira projects"""
    try:
        projects = await jira_service.get_projects()
        return ProjectResponse(projects=projects, total=len(projects))
    except Exception as e:
        logger.error(f"Error in get_projects endpoint: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch projects")

@router.get("/boards", response_model=List[JiraBoard])
async def get_boards(project_key: Optional[str] = Query(None, description="Filter by project key")):
    """Get Jira boards, optionally filtered by project"""
    try:
        print(f"Fetching boards for project_key: 24300")
        boards = await jira_service.get_boards(24300)
        return boards
    except Exception as e:
        logger.error(f"Error in get_boards endpoint: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch boards")
    
@router.get("/sprints/ordered", response_model=SprintResponse)
async def get_sprints_ordered(board_id: Optional[int] = Query(None, description="Board ID to get sprints from")):
    """Get sprints ordered with active sprints first"""
    try:
        if board_id:
            print(f"Fetching ordered sprints for board_id: {board_id}")
            sprints = await jira_service.get_sprints_ordered(board_id)
        else:
            print("Fetching all ordered sprints")
            sprints = await jira_service.get_all_sprints_ordered()
        
        return SprintResponse(sprints=sprints, total=len(sprints))
    except Exception as e:
        logger.error(f"Error in get_sprints_ordered endpoint: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch ordered sprints")

@router.get("/components", response_model=List[dict])
async def get_components(project_key: Optional[str] = Query(None, description="Filter by project key")):
    """Get components from a specific project or all projects"""
    try:
        if project_key:
            components = await jira_service.get_components(project_key)
        else:
            components = await jira_service.get_all_components()
        
        return components
    except Exception as e:
        logger.error(f"Error in get_components endpoint: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch components")

@router.get("/versions")
async def list_versions(
    all: bool = Query(True, description="Fetch all pages via /version"),
    max_per_page: int = 50,
    query: Optional[str] = None,
    status: Optional[str] = None,
    order_by: Optional[str] = None,
):
    if all:
        return await jira_service.get_project_versions_all(
            project_id_or_key=24300,
            max_per_page=max_per_page,
            query=query,
            status=status,
            order_by=order_by,
        )
    else:
        return await jira_service.get_project_versions_limit(
            project_id_or_key=24300,
            max_per_page=10,
            query=query,
            status=status,
            order_by=order_by,
        )

@router.get("/users/picker")
async def users_picker_route(
    query: str = Query(..., description="Search string"),
    max_results: int = Query(20, ge=1, le=100),
    show_avatar: bool = Query(True),
    avatar_size: str = Query("24x24"),
    exclude_account_ids: Optional[List[str]] = Query(None),
    exclude: Optional[List[str]] = Query(None),
    exclude_connect_users: bool = Query(True),
):
    try:
        return await jira_service.user_picker(
            query=query,
            max_results=max_results,
            show_avatar=show_avatar,
            avatar_size=avatar_size,
            exclude_account_ids=exclude_account_ids,
            exclude=exclude,
            exclude_connect_users=exclude_connect_users,
        )
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"user_picker failed: {e}")

@router.get("/issues/{issue_id_or_key}")
async def get_issue_route(
    issue_id_or_key: str = Path(..., description="Jira issue ID or key, e.g. '123456' or 'SE2-123'"),
    fields: Optional[str] = Query(None, description="Comma-separated fields, e.g. 'summary,status,customfield_10007'"),
    expand: Optional[str] = Query(None, description="Comma-separated expansions, e.g. 'changelog,renderedFields'"),
    properties: Optional[str] = Query(None, description="Comma-separated entity properties"),
):
    """
    Proxy to Jira Cloud: GET /rest/api/3/issue/{issueIdOrKey}

    Usage examples:
    - /api/jira/issues/SE2-123
    - /api/jira/issues/SE2-123?fields=summary,status,customfield_10007
    - /api/jira/issues/SE2-123?expand=changelog
    """
    try:
        issue = await jira_service.get_issue(
            issue_id_or_key,
            fields=_csv_to_list(fields),
            expand=_csv_to_list(expand),
            properties=_csv_to_list(properties),
        )
        return issue
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Failed to fetch issue: {e}")

@router.get("/test-cases/paginated")
async def get_test_cases_paginated(
    project_key: str = Query("SE2", description="Project key"),
    jql_filter: Optional[str] = Query(None, description="Additional JQL filter"),
    start_at: int = Query(0, description="Start index for pagination"),
    max_results: int = Query(50, description="Maximum results per page"),
    search: Optional[str] = Query(None, description="Search term for summary/description"),
    component: Optional[str] = Query(None, description="Filter by component"),
    sprint: Optional[str] = Query(None, description="Filter by sprint (id or name)"),
    status: Optional[str] = Query(None, description="Filter by status"),
    assignee: Optional[str] = Query(None, description="Filter by assignee (comma-separated, supports 'Unassigned')"),
    assigneeCurrentUser: Optional[bool] = Query(None, description="Filter by current user as assignee"),
    reporter: Optional[str] = Query(None, description="Filter by reporter (comma-separated, supports 'Unassigned')"),
    reporterCurrentUser: Optional[bool] = Query(None, description="Filter by current user as reporter"),
    issueLink: Optional[List[str]] = Query(None, description="Filter by linked issues (keys)"),
    issueType: Optional[str] = Query(None, description="Issue type to filter")
):
    """Get Test type issues with pagination and JQL filtering"""
    try:
        filters: List[str] = []

        # Always anchor on project (unless your jira_service already does this)
        if project_key:
            filters.append(f'project = "{_quote(project_key)}"')

        # Search in summary/description
        if search and search.strip():
            s = _quote(search.strip())
            filters.append(f'(summary ~ "{s}" OR description ~ "{s}")')

        # Component
        if component and component.strip() and component != "All Components":
            filters.append(f'component = "{_quote(component.strip())}"')

        # Sprint: id (no quotes) or name (quoted)
        if sprint and sprint.strip() and sprint != "All Sprints":
            s = sprint.strip()
            if _is_int(s):
                filters.append(f"Sprint = {s}")
            else:
                filters.append(f'Sprint = "{_quote(s)}"')

        # Status
        if status and status.strip() and status != "All Statuses":
            filters.append(f'status = "{_quote(status.strip())}"')

        # Issue Type
        if issueType and issueType.strip():
            filters.append(f'issuetype = "{_quote(issueType.strip())}"')

        # Assignee (CSV + current user + Unassigned)
        assignee_clause = _assignee_or_reporter_filter(
            field="assignee",
            csv_value=assignee,
            include_current_user=assigneeCurrentUser
        )
        if assignee_clause:
            filters.append(assignee_clause)

        # Reporter (CSV + current user + Unassigned)
        reporter_clause = _assignee_or_reporter_filter(
            field="reporter",
            csv_value=reporter,
            include_current_user=reporterCurrentUser
        )
        if reporter_clause:
            filters.append(reporter_clause)

        # Linked issues — use linkedIssues()
        if issueLink:
            keys = [k.strip().upper() for k in issueLink if k and k.strip()]
            if keys:
                li = ' OR '.join([f'issue IN linkedIssues("{_quote(k)}")' for k in keys])
                filters.append(f'({li})')

        combined_filter = " AND ".join(filters) if filters else None

        # Merge with user-provided JQL
        if jql_filter and jql_filter.strip():
            jf = jql_filter.strip()
            combined_filter = f'({jf})' if not combined_filter else f'({jf}) AND ({combined_filter})'

        logger.info(f"Combined JQL filter: {combined_filter or '<none>'}")
        logger.info(f"Jql filter: {jql_filter or '<none>'}")

        result = await jira_service.get_test_issues_paginated(
            project_key=project_key,
            jql_filter=combined_filter,
            start_at=start_at,
            max_results=max_results
        )
        return result

    except Exception:
        logger.exception("Error in get_test_cases_paginated endpoint")
        raise HTTPException(status_code=500, detail="Failed to fetch paginated test cases")


@router.post("/test-cases") 
async def create_test_case(body: CreateTestCaseBody
):
    """Create a new Test type issue in Jira"""
    try:
        new_issue = await jira_service.create_test_issue(
            project_key=body.project_key,
            summary=body.summary,
            description=body.description,
            components=body.components,
            related_issues=body.related_issues if body.related_issues else None,  # no related issues on creation
            custom_fields={"customfield_10007": body.sprint_id} if body.sprint_id else None  # Adjust custom field ID as needed
        )
        print(f"Created new Jira Test issue: {new_issue}")
        return new_issue
    except Exception as e:
        logger.error(f"Error in create_test_case endpoint: {e}")
        raise HTTPException(status_code=500, detail="Failed to create test case")

@router.get("/health")
async def jira_health_check():
    """FastAPI route to check if Jira API is accessible"""
    try:
        result = await jira_service.jira_health_check()
        return {"status": "ok", "data": result}
    except Exception as e:
        logger.error("Jira health check API failed: %s", e)
        return {"status": "error", "message": str(e)}


@router.put("/test-cases/{issue_id_or_key}")
async def update_test_case(
    issue_id_or_key: str = Path(..., description="Jira issue ID or key"),
    payload: UpdateTestCaseRequest = ...,
):
    """Update Jira fields of a test case"""
    try:
        data = payload.model_dump(by_alias=False, exclude_none=True)
        logger.info("Update payload for %s: %s", issue_id_or_key, data)

        update_fields: dict = {}

        if "summary" in data:
            update_fields["summary"] = data["summary"]

        if "description" in data:
            update_fields["description"] = data["description"]

        if "component" in data:
            # Jira expects components as a list of objects
            update_fields["components"] = [{"name": data["component"]}]

        if "sprint" in data:
            # often customfield_10007 or your instance-specific sprint field
            update_fields["customfield_10007"] = data["sprint"]

        if "status" in data:
            # NOTE: Jira status changes are usually done via transitions, not field update
            update_fields["status"] = {"name": data["status"]}

        if "priority" in data:
            update_fields["priority"] = {"name": data["priority"]}

        if "related_task" in data:
            # TODO: implement linking logic if you need to create issue links
            pass

        if not update_fields:
            return {"success": True, "message": "No fields to update"}

        # --- call your Jira service ---
        result = await jira_service.update_issue(issue_id_or_key, update_fields)

        return {
            "success": True,
            "message": "Test case updated successfully",
            "updated_fields": list(update_fields.keys()),
        }

    except Exception as e:
        logger.error("Error updating test case %s: %s", issue_id_or_key, e)
        raise HTTPException(status_code=500, detail=f"Failed to update test case: {e}")

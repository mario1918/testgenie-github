# routers/test_case.py (new orchestrator)
from fastapi import APIRouter, HTTPException, Path
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import asyncio

from app.models.test_case import FullCreateBody, CreateExecutionRequest, CreateExecutionResponse
from app.services.jira_service import jira_service
from app.services.zephyr_service import PROJECT_ID, zephyr_service

router = APIRouter(prefix="/api/test-cases", tags=["test-cases"])


@router.post("/full-create")
async def full_create_tc(body: FullCreateBody):
    """
    1) Create Jira Test issue
    2) Add Zephyr steps
    3) In parallel with (2): add to version/cycle (create execution)
    4) Update execution status (optional)
    """
    try:
      # 1) Create Jira Test
      print(f"Creating Jira Test in project {PROJECT_ID} with summary: {body.summary}")
      created = await jira_service.create_test_issue(
          project_key=PROJECT_ID,
          summary=body.summary,
          description=body.description,
          components=body.components or [],
          related_issues=body.related_issues or [],
          custom_fields={"customfield_10007": body.sprint_id} if body.sprint_id else None
      )
      issue_id = str(created["id"])   # numeric id
      issue_key = created["key"]      # "SE2-xxxx"

      # Optional: assign sprint AFTER creation if you need it (Agile API)
      print(f"Created Jira Test: {issue_key} (ID: {issue_id})")
      print(f"Assigned to sprint {body.sprint_id}")
      # 2) Add steps to Zephyr (if any)
      print(f"Adding steps to Zephyr Test {issue_key} (ID: {issue_id})")
      add_steps_task = None
      if body.steps:
          add_steps_task = asyncio.create_task(zephyr_service.add_test_steps(
              issue_id=issue_id,
              project_id=PROJECT_ID,
              steps=body.steps
          ))
      print(f"Steps addition task created: {add_steps_task is not None}")
      # 3) Add to version/cycle (create execution) if both provided
      print(f"Adding to cycle/version if provided" f"(cycle_id={body.cycle_id}, version_id={body.version_id})")
      add_to_cycle_task = None
      if body.version_id is not None and body.cycle_id is not None:
          add_to_cycle_task = asyncio.create_task(zephyr_service.add_test_to_cycle(
              issue_id=issue_id,
              project_id=PROJECT_ID,
              cycle_id=body.cycle_id,
              folder_id=None,
              version_id=body.version_id
          ))
      print(f"Add to cycle task created: {add_to_cycle_task is not None}")
      # Run (2) & (3) in parallel (whatever exists)
      print("Waiting for async tasks to complete...")
      exec_id = None
      if add_steps_task and add_to_cycle_task:
          steps_res, add_cycle_res = await asyncio.gather(add_steps_task, add_to_cycle_task)
          exec_id = (add_cycle_res or {}).get("execution_id")
      elif add_steps_task:
          await add_steps_task
      elif add_to_cycle_task:
          add_cycle_res = await add_to_cycle_task
          exec_id = (add_cycle_res or {}).get("execution_id")
      print(f"Async tasks completed. Execution ID: {exec_id}")
      # 4) If we have an execution AND user asked for a status → execute it
      print(f"Setting execution status if needed (exec_id={exec_id}), body.execution_status={body.execution_status}")
      if exec_id and body.execution_status:
        print(f"Setting execution status to {body.execution_status.get('id')}")
        status_id = body.execution_status.get("id")
        await zephyr_service.execute_test(
                  project_id=PROJECT_ID,
                  issue_id=int(issue_id),
                  execution_id=str(exec_id),
                  status_id=int(status_id)
          )
      return {
          "jira": {"id": issue_id, "key": issue_key},
          "execution_id": exec_id or None
      }

    except HTTPException:
      raise
    except Exception as e:
      raise HTTPException(status_code=502, detail=f"Full create failed: {e}")

@router.post("/{issue_id}/execution", response_model=CreateExecutionResponse)
async def create_execution_route(
    issue_id: str = Path(..., description="Jira issueId (numeric) of the Test"),
    body: CreateExecutionRequest = ...,
    ):
        """
        Create (or find) a Zephyr execution for the Test in the given cycle.
        If 'execution_status.id' is provided, immediately set the execution status.
        """
        try:
            # sanity-check: path and body issue_id should match, but trust path param
            if body.issue_id and str(body.issue_id) != str(issue_id):
                logger.warning("Body issue_id (%s) != path issue_id (%s); using path value.", body.issue_id, issue_id)

            status_id = body.execution_status.id if body.execution_status else None

            res = await zephyr_service.create_execution_and_optionally_execute(
                issue_id=issue_id,
                project_id=PROJECT_ID,
                cycle_id=body.cycle_id,
                version_id=body.version_id,
                status_id=status_id,
            )

            if not res.get("execution_id"):
                # If the service couldn't produce/find an execution, treat it as a bad upstream outcome
                raise HTTPException(status_code=502, detail="Failed to create or locate execution")

            return CreateExecutionResponse(
                issue_id=str(issue_id),
                project_id=PROJECT_ID,
                cycle_id=body.cycle_id,
                version_id=body.version_id,
                execution_id=str(res["execution_id"]),
                created=bool(res.get("created")),
                status_updated=bool(res.get("status_updated")),
            )
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=502, detail=f"Create execution failed: {e}")
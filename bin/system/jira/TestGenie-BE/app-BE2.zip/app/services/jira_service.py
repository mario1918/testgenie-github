# =============================================================
# Jira Service
# - Helper utilities (ADF, date parsing)
# - Projects / Boards / Sprints
# - Components / Versions
# - Issues (search, create, link)
# =============================================================
import httpx
import base64
from typing import List, Optional, Dict, Any
from datetime import datetime
from app.core.config import settings
from app.models.jira import JiraSprint, JiraProject, JiraBoard, JiraIssue
import logging

logger = logging.getLogger(__name__)

# --- Helpers ---------------------------------------------------

def _adf_from_text(text: str) -> dict:
        """Convert plain text (with newlines) to a minimal ADF document."""
        lines = (text or "").splitlines() or [""]
        content = []
        for line in lines:
            if line.strip() == "":
                content.append({"type": "paragraph"})
            else:
                content.append({
                    "type": "paragraph",
                    "content": [{"type": "text", "text": line}]
                })
        return {"type": "doc", "version": 1, "content": content}

      
class JiraService:
    def __init__(self):
        self.base_url = settings.jira_base_url
        self.username = settings.jira_username
        self.api_token = settings.jira_api_token
        self.default_assignee_account_id = settings.zephyr_account_id
        # Create basic auth header
        credentials = f"{self.username}:{self.api_token}"
        encoded_credentials = base64.b64encode(credentials.encode()).decode()
        self.headers = {
            "Authorization": f"Basic {encoded_credentials}",
            "Accept": "application/json",
            "Content-Type": "application/json"
        }
    
    def _parse_iso(self, dt: Optional[str]) -> Optional[datetime]:
        if not dt:
            return None
        # Jira sends Z or +hh:mm offsets
        try:
            return datetime.fromisoformat(dt.replace("Z", "+00:00"))
        except Exception:
            return None
    # Projects -----------------------------------------------

    

    async def get_projects(self) -> List[JiraProject]:
        """Get the specific Jira project SE 2.0"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{self.base_url}/rest/api/3/project",
                    headers=self.headers,
                    timeout=30.0
                )
                response.raise_for_status()
                
                projects_data = response.json()
                projects = []
                
                for project_data in projects_data:
                    if (
                        project_data.get("id") == "24300" and
                        project_data.get("key") == "SE2" and
                        project_data.get("name") == "SE 2.0"
                    ):
                        project = JiraProject(
                            id=project_data["id"],
                            key=project_data["key"],
                            name=project_data["name"],
                            description=project_data.get("description")
                        )
                        projects.append(project)
                        break  # stop once we find it
                
                if projects:
                    print(f"Retrieved project: {projects[0]}")
                else:
                    print("Project SE 2.0 not found")
                
                return projects

        except httpx.HTTPError as e:
            logger.error(f"HTTP error getting project: {e}")
            return []
        except Exception as e:
            logger.error(f"Error getting project: {e}")
            return []
    # Boards -------------------------------------------------

 
    async def get_boards(self, project_key: Optional[str] = None) -> List[JiraBoard]:
        """Get Jira boards, optionally filtered by project"""
        try:
            url = f"{self.base_url}/rest/agile/1.0/board"
            params = {}
            if project_key:
                params["projectKeyOrId"] = project_key
            
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    url,
                    headers=self.headers,
                    params=params,
                    timeout=30.0
                )
                response.raise_for_status()
                
                data = response.json()
                boards = []
                
                for board_data in data.get("values", []):
                    board = JiraBoard(
                        id=board_data["id"],
                        name=board_data["name"],
                        type=board_data["type"],
                        project_key=board_data.get("location", {}).get("projectKey", "")
                    )
                    boards.append(board)
                print(f"Retrieved {len(boards)} boards: {boards}")
                return boards
                
        except httpx.HTTPError as e:
            logger.error(f"HTTP error getting boards: {e}")
            return []
        except Exception as e:
            logger.error(f"Error getting boards: {e}")
            return []
    # Sprints (ordered) --------------------------------------

    
    async def get_sprints_ordered(self, board_id: int) -> List[JiraSprint]:
        """Get sprints for a specific board with active/future first, then closed (paged)."""
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                async def fetch_state(state: str | None) -> list[dict]:
                    params = {"maxResults": 50}
                    if state:
                        params["state"] = state
                    start_at = 0
                    out: list[dict] = []
                    while True:
                        params["startAt"] = start_at
                        r = await client.get(
                            f"{self.base_url}/rest/agile/1.0/board/{board_id}/sprint",
                            headers=self.headers,
                            params=params,
                        )
                        r.raise_for_status()
                        page = r.json()
                        values = page.get("values", [])
                        out.extend(values)
                        # advance by actual count returned
                        if page.get("isLast") or not values:
                            break
                        start_at += len(values)
                    return out

                # 1) Active + future first
                active_future_raw = await fetch_state("active,future")
                # 2) Then closed
                closed_raw = await fetch_state("closed")

                # Combine (active/future first), de-duping by id just in case
                seen: set[int] = set()
                ordered_raw: list[dict] = []
                for s in active_future_raw + closed_raw:
                    sid = s.get("id")
                    if sid not in seen:
                        ordered_raw.append(s)
                        seen.add(sid)

                # Map to JiraSprint models
                sprints: List[JiraSprint] = [
                    JiraSprint(
                        id=s["id"],
                        name=s["name"],
                        state=s["state"],
                        start_date=s.get("startDate"),
                        end_date=s.get("endDate"),
                        complete_date=s.get("completeDate"),
                        board_id=board_id,
                    )
                    for s in ordered_raw
                ]

                # Final stable sort: active < future < closed, then by name
                def sort_key(sp: JiraSprint):
                    order = {"active": 0, "future": 1, "closed": 2}
                    return (order.get(sp.state, 3), sp.name or "")

                sprints.sort(key=sort_key)

                print(f"Retrieved and ordered {len(sprints)} sprints for board {board_id}")
                return sprints

        except httpx.HTTPError as e:
            logger.error(f"HTTP error getting ordered sprints: {e}")
            return []
        except Exception as e:
            logger.error(f"Error getting ordered sprints: {e}")
            return []
    # Sprints (all boards) -----------------------------------

    
    async def get_all_sprints_ordered(self) -> List[JiraSprint]:
        """Get all sprints from all accessible boards, ordered with active sprints first"""
        try:
            # boards = await self.get_boards(24300)  # Use the specific project key
            all_sprints = []

            sprints= await self.get_sprints_ordered(1098)
            all_sprints.extend(sprints)
            
            # Sort all sprints globally: active first, then future, then closed
            def sort_key(sprint):
                if sprint.state == "active":
                    return (0, sprint.name)
                elif sprint.state == "future":
                    return (1, sprint.name)
                else:  # closed
                    return (2, sprint.name)
            
            all_sprints.sort(key=sort_key)
            return all_sprints
            
        except Exception as e:
            logger.error(f"Error getting all ordered sprints: {e}")
            return []
    # Components --------------------------------------------

    
    async def get_components(self, project_key: str) -> List[dict]:
        """Get components for a specific project"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{self.base_url}/rest/api/3/project/{project_key}/components",
                    headers=self.headers,
                    timeout=30.0
                )
                response.raise_for_status()
                
                components_data = response.json()
                components = []
                
                for component_data in components_data:
                    component = {
                        "id": component_data["id"],
                        "name": component_data["name"],
                        "description": component_data.get("description", ""),
                        "project_key": project_key
                    }
                    components.append(component)

                return components
                
        except httpx.HTTPError as e:
            logger.error(f"HTTP error getting components: {e}")
            return []
        except Exception as e:
            logger.error(f"Error getting components: {e}")
            return []
    
    async def get_all_components(self) -> List[dict]:
        """Get components from all accessible projects"""
        try:
            projects = await self.get_projects()
            all_components = []
            
            for project in projects:
                components = await self.get_components(project.key)
                all_components.extend(components)
            
            return all_components
            
        except Exception as e:
            logger.error(f"Error getting all components: {e}")
            return []
   
    async def get_project_versions_all(
        self,
        project_id_or_key: str,
        max_per_page: int = 50,
        timeout: float = 30.0,
        query: Optional[str] = None,
        status: Optional[str] = None,   # "released", "unreleased", "archived" (per Jira)
        order_by: Optional[str] = None, # e.g. "name", "releaseDate"
    ) -> List[Dict[str, Any]]:
        """
        Fetch *all* versions for a project by paging over:
        GET /rest/api/3/project/{projectIdOrKey}/version
        """
        start_at = 0
        out: List[Dict[str, Any]] = []

        async with httpx.AsyncClient(timeout=timeout) as client:
            while True:
                params: Dict[str, Any] = {
                    "startAt": start_at,
                    "maxResults": max_per_page,
                }
                if query:    params["query"] = query
                if status:   params["status"] = status
                if order_by: params["orderBy"] = order_by

                r = await client.get(
                    f"{self.base_url}/rest/api/3/project/{project_id_or_key}/version",
                    headers=self.headers,
                    params=params,
                )
                r.raise_for_status()
                page = r.json() or {}
                values = page.get("values", [])
                out.extend(values)
                
                for version in out:
                    if version.get("archived") == True:
                        print(f"Removing archived version: {version}")
                        out.remove(version)

                if page.get("isLast") or not values:
                    break
                start_at += len(values)

        # normalize a minimal shape you likely need
        return [
            {
                "id": v.get("id"),
                "name": v.get("name"),
                "released": v.get("released"),
                "archived": v.get("archived"),
                "releaseDate": v.get("releaseDate"),
                "projectId": v.get("projectId"),
            }
            for v in out
        ]

    async def get_project_versions_limit(
        self,
        project_id_or_key: str,
        max_per_page: int = 10,
        timeout: float = 30.0,
        query: Optional[str] = None,
        status: Optional[str] = None,   # "released", "unreleased", "archived" (per Jira)
        order_by: Optional[str] = None, # e.g. "name", "releaseDate"
    ) -> List[Dict[str, Any]]:
        """
        Fetch *all* versions for a project by paging over:
        GET /rest/api/3/project/{projectIdOrKey}/version
        """
        start_at = 0
        out: List[Dict[str, Any]] = []
        async with httpx.AsyncClient(timeout=timeout) as client:
            params: Dict[str, Any] = {
                    "startAt": start_at,
                    "maxResults": max_per_page,
                }
            if query:    params["query"] = query
            if status:   params["status"] = status
            if order_by: params["orderBy"] = order_by

            r = await client.get(
                    f"{self.base_url}/rest/api/3/project/{project_id_or_key}/version",
                    headers=self.headers,
                    params=params,
                )
            r.raise_for_status()
            page = r.json() or {}
            values = page.get("values", [])
            out.extend(values)
            
            for version in out:
                if version.get("archived") == True or version.get("archived") == "true":
                    out.remove(version)

        # normalize a minimal shape you likely need
        return [
            {
                "id": v.get("id"),
                "name": v.get("name"),
                "released": v.get("released"),
                "archived": v.get("archived"),
                "releaseDate": v.get("releaseDate"),
                "projectId": v.get("projectId"),
            }
            for v in out
        ]

    async def get_project_versions_unpaginated(
        self,
        project_id_or_key: str,
        timeout: float = 30.0,
    ) -> List[Dict[str, Any]]:
        """
        Single call (not paginated):
        GET /rest/api/3/project/{projectIdOrKey}/versions
        """
        async with httpx.AsyncClient(timeout=timeout) as client:
            r = await client.get(
                f"{self.base_url}/rest/api/3/project/{project_id_or_key}/versions",
                headers=self.headers,
            )
            r.raise_for_status()
            arr = r.json() or []
        return arr
    
    async def user_picker(
        self,
        *,
        query: str,
        max_results: int = 20,
        show_avatar: bool = True,
        avatar_size: str = "24x24",
        exclude_account_ids: Optional[List[str]] = None,
        exclude: Optional[List[str]] = None,
        exclude_connect_users: bool = True,
        timeout: float = 30.0,
    ) -> Dict[str, Any]:
        """
        Call Jira Cloud user picker to find users by a free-text query.
        Returns: {"total": int, "users": [{"accountId","displayName","avatarUrl","html"}...]}

        Docs: GET /rest/api/3/user/picker (FoundUsers response).  # query required
        """
        if not query or not str(query).strip():
            raise ValueError("query is required for user_picker")

        params: Dict[str, Any] = {
            "query": query,
            "maxResults": max_results,
            "showAvatar": str(bool(show_avatar)).lower(),
            "avatarSize": avatar_size,
            "excludeConnectUsers": str(bool(exclude_connect_users)).lower(),
        }
        # Arrays are encoded as repeated params by httpx (excludeAccountIds=A&excludeAccountIds=B)
        if exclude_account_ids:
            params["excludeAccountIds"] = exclude_account_ids
        if exclude:
            params["exclude"] = exclude

        url = f"{self.base_url}/rest/api/3/user/picker"
        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                r = await client.get(url, headers=self.headers, params=params)
                r.raise_for_status()
                data = r.json() or {}

            # Normalize to a compact shape
            users = [
                {
                    "accountId": u.get("accountId"),
                    "displayName": u.get("displayName"),
                    "avatarUrl": u.get("avatarUrl"),   # already size-adjusted per avatarSize
                    "html": u.get("html"),             # highlighted name/email with <strong>
                }
                for u in (data.get("users") or [])
            ]
            return {
                "total": int(data.get("total") or len(users) or 0),
                "users": users,
            }

        except httpx.HTTPError as e:
            msg = getattr(e.response, "text", str(e))
            logger.error("Jira user_picker failed: %s", msg)
            raise
    # Test issues (paginated) --------------------------------
    async def get_issue(
        self,
        issue_id_or_key: str,
        *,
        fields: Optional[List[str]] = None,
        expand: Optional[List[str]] = None,
        properties: Optional[List[str]] = None,
        timeout: float = 30.0,
    ) -> Dict[str, Any]:
        """
        GET a Jira issue by ID or key.

        Jira API: GET /rest/api/3/issue/{issueIdOrKey}
        - fields: list of field ids/names to return (e.g. ["summary","status","customfield_10007"])
        - expand: list of expansions (e.g. ["changelog","renderedFields"])
        - properties: list of entity property keys to include

        Returns: full issue JSON (dict). Raises on HTTP errors.
        """
        params: Dict[str, str] = {}
        if fields:
            params["fields"] = ",".join(fields)
        if expand:
            params["expand"] = ",".join(expand)
        if properties:
            params["properties"] = ",".join(properties)

        url = f"{self.base_url}/rest/api/3/issue/{issue_id_or_key}"

        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                r = await client.get(url, headers=self.headers, params=params)
                r.raise_for_status()
                return r.json() or {}
        except httpx.HTTPStatusError as e:
            text = e.response.text if e.response is not None else str(e)
            logger.error("Jira get_issue failed for %s: %s", issue_id_or_key, text)
            raise
        except Exception as e:
            logger.error("Error getting issue %s: %s", issue_id_or_key, e)
            raise
   
    async def get_test_issues_paginated(
            self, 
            project_key: str = "SE2", 
            jql_filter: Optional[str] = None,
            start_at: int = 0,
            max_results: int = 50
        ) -> dict:
            """Get Test type issues with pagination and JQL filtering"""
            try:
                # Base JQL for test issues
                base_jql = f"project = {project_key}"
                
                # Add additional JQL filter if provided
                if jql_filter:
                    jql = f"{base_jql} AND ({jql_filter})"
                else:
                    jql = base_jql
                
                params = {
                    "jql": jql,
                    "startAt": start_at,
                    "maxResults": max_results,
                    "fields": "summary,description,issuetype,status,priority,assignee,reporter,created,updated,components,customfield_10007,issuelinks"
                }
                
                async with httpx.AsyncClient() as client:
                    response = await client.get(
                        f"{self.base_url}/rest/api/3/search",
                        headers=self.headers,
                        params=params,
                        timeout=30.0
                    )
                    response.raise_for_status()
                    
                    data = response.json()
                    issues = []
                    
                    for issue_data in data.get("issues", []):
                        fields = issue_data["fields"]
                        
                        # Extract description text
                        description = ""
                        if fields.get("description") and fields["description"].get("content"):
                            for content in fields["description"]["content"]:
                                if content.get("content"):
                                    for text_content in content["content"]:
                                        if text_content.get("text"):
                                            description += text_content["text"] + " "
                        
                        # Extract components
                        components = []
                        if fields.get("components"):
                            components = [comp["name"] for comp in fields["components"]]
                        
                        # Extract sprint information
                        sprints = fields.get("customfield_10007") or []
                        sprint_name = sprints[-1]["name"] if isinstance(sprints, list) and sprints else "N/A"
                        
                        # Extract first linked issue
                        first_linked_key = next((
                            ( (link.get("inwardIssue") or link.get("outwardIssue") or {}).get("key") )
                            for link in (fields.get("issuelinks") or [])
                            if (link.get("inwardIssue") or link.get("outwardIssue"))
                        ), None)
                        
                        issue = JiraIssue(
                            id=issue_data["id"],
                            key=issue_data["key"],
                            summary=fields["summary"],
                            description=description.strip(),
                            issue_type=fields["issuetype"]["name"],
                            status=fields["status"]["name"],
                            priority=fields["priority"]["name"] if fields.get("priority") else "Medium",
                            assignee=fields["assignee"]["displayName"] if fields.get("assignee") else None,
                            reporter=fields["reporter"]["displayName"],
                            created=fields["created"],
                            updated=fields["updated"],
                            components=components,
                            sprint=sprint_name,
                            first_linked_issue=first_linked_key
                        )
                        issues.append(issue)
                    
                    return {
                        "issues": issues,
                        "total": data.get("total", 0),
                        "startAt": data.get("startAt", 0),
                        "maxResults": data.get("maxResults", max_results),
                        "isLast": start_at + len(issues) >= data.get("total", 0),
                    }
                    
            except httpx.HTTPError as e:
                logger.error(f"HTTP error getting paginated test issues: {e}")
                return {
                    "issues": [],
                    "total": 0,
                    "startAt": 0,
                    "maxResults": max_results,
                    "isLast": True
                }
            except Exception as e:
                logger.error(f"Error getting paginated test issues: {e}")
                return {
                    "issues": [],
                    "total": 0,
                    "startAt": 0,
                    "maxResults": max_results,
                    "isLast": True
                }
    # Create Test issue --------------------------------------

    
    async def create_test_issue(
        self,
        *,
        project_key: str,
        summary: str,
        description: Optional[str] = None,
        components: Optional[List[str]] = None,      # component names
        related_issues: Optional[List[str]] = None,  # issue keys to link to
        link_type_name: str = "Relates",             # Jira link type name
        custom_fields: Optional[Dict[str, Any]] = None,  # extra fields by id
        timeout: float = 30.0,
    ) -> Dict[str, Any]:
        """
        Create a Jira Cloud issue of type 'Test' and link it to other issues.
        Returns basic issue info plus link results.
        """
        fields: Dict[str, Any] = {
            "project": {"id": project_key},
            "summary": summary,
            "issuetype": {"name": "Test"},
        }

        if description is not None:
            if isinstance(description, dict) and description.get("type") == "doc":
                fields["description"] = description  # already ADF
            else:
                fields["description"] = _adf_from_text(str(description))
                
        # Assign to default assignee if configured
        if getattr(self, "default_assignee_account_id", None):
            fields["assignee"] = {"accountId": self.default_assignee_account_id}

        if components:
            fields["components"] = [{"name": c} for c in components if c]

        if custom_fields:
            fields.update(custom_fields)

        body = {"fields": fields}
        logger.debug("Creating Jira Test issue with body: %s", body)

        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                # 1) Create the issue
                r = await client.post(
                    f"{self.base_url}/rest/api/3/issue",
                    headers=self.headers,
                    json=body,
                )
                r.raise_for_status()
                data = r.json()
                issue_key = data["key"]
                issue_id = int(data["id"])

                result: Dict[str, Any] = {
                    "id": issue_id,
                    "key": issue_key,
                    "self": data.get("self"),
                    "raw": data,
                    "links_created": 0,
                    "link_errors": [],
                }

                # 2) Link to related issues (if any)
                if related_issues:
                    for rel_key in related_issues:
                        if not rel_key:
                            continue
                        try:
                            link_payload = {
                                "type": {"name": link_type_name},
                                # Make the NEW issue the outward side; the existing is inward.
                                "outwardIssue": {"key": issue_key},
                                "inwardIssue": {"key": rel_key},
                            }
                            lr = await client.post(
                                f"{self.base_url}/rest/api/3/issueLink",
                                headers=self.headers,
                                json=link_payload,
                            )
                            lr.raise_for_status()
                            result["links_created"] += 1
                        except httpx.HTTPError as le:
                            msg = getattr(le.response, "text", str(le))
                            logger.error("Issue link to %s failed: %s", rel_key, msg)
                            result["link_errors"].append({"related": rel_key, "error": msg})

                return result

        except httpx.HTTPStatusError as e:
            text = e.response.text if e.response is not None else str(e)
            logger.error("Jira create issue failed: %s", text)
            raise
        except Exception as e:
            logger.error("Error creating Jira test issue: %s", e)
            raise
    
    async def update_issue(
        self,
        issue_id_or_key: str,
        update_fields: Dict[str, Any],
        timeout: float = 30.0
    ) -> bool:
        """
        Update a Jira issue with the provided fields
        """
        try:
            # Convert description to ADF if it's a string
            if "description" in update_fields and isinstance(update_fields["description"], str):
                update_fields["description"] = _adf_from_text(update_fields["description"])
            
            body = {"fields": update_fields}
            logger.debug(f"Updating Jira issue {issue_id_or_key} with body: {body}")
            
            async with httpx.AsyncClient(timeout=timeout) as client:
                response = await client.put(
                    f"{self.base_url}/rest/api/3/issue/{issue_id_or_key}",
                    headers=self.headers,
                    json=body,
                )
                response.raise_for_status()
                return True
                
        except httpx.HTTPError as e:
            logger.error(f"HTTP error updating issue {issue_id_or_key}: {e}")
            if hasattr(e, 'response') and e.response:
                logger.error(f"Response content: {e.response.text}")
            raise
        except Exception as e:
            logger.error(f"Error updating issue {issue_id_or_key}: {e}")
            raise



    async def jira_health_check(self) -> Dict[str, Any]:
        """Call Jira support health check endpoint"""
        url = f"{self.base_url}/rest/supportHealthCheck/1.0/check/"
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                r = await client.get(url, headers=self.headers)
                r.raise_for_status()
                return r.json() or {}
        except httpx.HTTPStatusError as e:
            text = e.response.text if e.response is not None else str(e)
            logger.error("Jira health check failed with status %s: %s", e.response.status_code if e.response else "?", text)
            raise
        except Exception as e:
            logger.error("Error calling Jira health check: %s", e)
            raise
    

        
# Create a singleton instance
jira_service = JiraService()


    
from pydantic import BaseModel, Field, model_validator
from typing import Optional, List, Dict, Any
from datetime import datetime
from enum import Enum

class ZephyrTestCaseStatus(str, Enum):
    DRAFT = "Draft"
    APPROVED = "Approved"
    DEPRECATED = "Deprecated"

class ZephyrTestStep(BaseModel):
    step: str = Field(..., description="Test step description")
    data: Optional[str] = Field(None, description="Test data")
    result: Optional[str] = Field(None, description="Expected result")

class ZephyrTestCaseCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255, description="Test case name")
    objective: Optional[str] = Field(None, description="Test case objective")
    precondition: Optional[str] = Field(None, description="Test preconditions")
    estimatedTime: Optional[int] = Field(None, description="Estimated time in seconds")
    labels: Optional[List[str]] = Field(default_factory=list, description="Test case labels")
    component: Optional[str] = Field(None, description="Component name")
    priority: Optional[str] = Field("Medium", description="Test case priority")
    status: Optional[ZephyrTestCaseStatus] = Field(ZephyrTestCaseStatus.DRAFT, description="Test case status")
    folder: Optional[str] = Field(None, description="Folder path")
    issueLinks: Optional[List[str]] = Field(default_factory=list, description="Linked Jira issues")

class ZephyrTestCaseUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    objective: Optional[str] = None
    precondition: Optional[str] = None
    estimatedTime: Optional[int] = None
    labels: Optional[List[str]] = None
    component: Optional[str] = None
    priority: Optional[str] = None
    status: Optional[ZephyrTestCaseStatus] = None
    folder: Optional[str] = None
    issueLinks: Optional[List[str]] = None

class ZephyrTestCase(BaseModel):
    id: str = Field(..., description="Test case ID")
    key: str = Field(..., description="Test case key")
    name: str = Field(..., description="Test case name")
    objective: Optional[str] = None
    precondition: Optional[str] = None
    estimatedTime: Optional[int] = None
    labels: List[str] = Field(default_factory=list)
    component: Optional[str] = None
    priority: str = "Medium"
    status: ZephyrTestCaseStatus = ZephyrTestCaseStatus.DRAFT
    folder: Optional[str] = None
    issueLinks: List[str] = Field(default_factory=list)
    createdOn: Optional[datetime] = None
    modifiedOn: Optional[datetime] = None
    createdBy: Optional[str] = None
    modifiedBy: Optional[str] = None
    projectId: Optional[str] = None

class ZephyrTestStepCreate(BaseModel):
    step: str = Field(..., description="Test step description")
    data: Optional[str] = Field(None, description="Test data")
    result: Optional[str] = Field(None, description="Expected result")

class ZephyrTestStepResponse(BaseModel):
    id: str
    step: str
    data: Optional[str] = None
    result: Optional[str] = None
    orderId: int

class ZephyrTestCaseWithSteps(ZephyrTestCase):
    testSteps: List[ZephyrTestStepResponse] = Field(default_factory=list)

class ZephyrTestCaseCreateRequest(BaseModel):
    testCase: ZephyrTestCaseCreate
    testSteps: Optional[List[ZephyrTestStepCreate]] = Field(default_factory=list)

class ZephyrTestCaseResponse(BaseModel):
    testCases: List[ZephyrTestCase]
    total: int
    startAt: int
    maxResults: int

class ZephyrBulkOperationResponse(BaseModel):
    success: bool
    message: str
    affectedIds: List[str]
    errors: Optional[List[str]] = None
    
class AddTestStepsResponse(BaseModel):
    issue_id: str
    project_id: int
    steps_created: int
    created_ids: List[str]
    errors: List[str]

class StepIn(BaseModel):
    step: str = Field(..., description="Step text")
    data: Optional[str] = Field(None, description="Test data")
    result: Optional[str] = Field(None, description="Expected result")

class AddTestStepsBody(BaseModel):
    steps: List[StepIn] = Field(..., description="Ordered list of steps")
    
class AddToCycleBody(BaseModel):
    cycle_id: int = Field(..., description="Zephyr cycle ID"),
    version_id: int = Field(..., description="Jira versionId (-1 for Unscheduled if supported)")
    folder_id: Optional[int] = Field(None, description="Optional Zephyr folder ID inside the cycle")

class AddToCycleResponse(BaseModel):
    issue_id: str
    project_id: int
    cycle_id: int
    version_id: int
    execution_id: Optional[str] = None
    created: bool = False
    error: Optional[str] = None


class CreateCycleBody(BaseModel):
    version_id: int = Field(..., description="Jira versionId (-1 for Unscheduled if supported)")
    name: str = Field(..., description="Cycle name")
    description: Optional[str] = None
    build: Optional[str] = None
    environment: Optional[str] = None
    start_date: Optional[str] = Field(None, description="YYYY-MM-DD")
    end_date: Optional[str]   = Field(None, description="YYYY-MM-DD")

class ExecuteBody(BaseModel):
    status: Optional[str]  = Field(None, description="PASS / FAIL / WIP / BLOCKED / UNEXECUTED")
    status_id: Optional[int] = Field(None, description="Zephyr execution status numeric id")
    cycle_id: Optional[int]  = Field(None, description="Use -1 for Ad hoc (optional)")
    version_id: Optional[int] = Field(None, description="Required when cycle_id = -1 (Ad hoc)")
    @model_validator(mode="after")
    def need_status(self):
        if self.status is None and self.status_id is None:
            raise ValueError("Provide either 'status' or 'status_id'.")
        return self
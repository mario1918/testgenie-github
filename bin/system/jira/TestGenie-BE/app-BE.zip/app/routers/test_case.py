# routers/test_case.py (new orchestrator)
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import asyncio

from app.models.test_case import FullCreateBody
from app.services.jira_service import jira_service
from app.services.zephyr_service import PROJECT_ID, zephyr_service

router = APIRouter(prefix="/api/test-cases", tags=["test-cases"])


@router.post("/full-create")
async def full_create_tc(body: FullCreateBody):
    """
    1) Create Jira Test issue
    2) Add Zephyr steps
    3) In parallel with (2): add to version/cycle (create execution)
    4) Update execution status (optional)
    """
    try:
      # 1) Create Jira Test
      print(f"Creating Jira Test in project {PROJECT_ID} with summary: {body.summary}")
      created = await jira_service.create_test_issue(
          project_key=PROJECT_ID,
          summary=body.summary,
          description=body.description,
          components=body.components or [],
          related_issues=body.related_issues or [],
          custom_fields={"customfield_10007": body.sprint_id} if body.sprint_id else None
      )
      issue_id = str(created["id"])   # numeric id
      issue_key = created["key"]      # "SE2-xxxx"

      # Optional: assign sprint AFTER creation if you need it (Agile API)
      print(f"Created Jira Test: {issue_key} (ID: {issue_id})")
      print(f"Assigned to sprint {body.sprint_id}")
      # 2) Add steps to Zephyr (if any)
      print(f"Adding steps to Zephyr Test {issue_key} (ID: {issue_id})")
      add_steps_task = None
      if body.steps:
          add_steps_task = asyncio.create_task(zephyr_service.add_test_steps(
              issue_id=issue_id,
              project_id=PROJECT_ID,
              steps=body.steps
          ))
      print(f"Steps addition task created: {add_steps_task is not None}")
      # 3) Add to version/cycle (create execution) if both provided
      print(f"Adding to cycle/version if provided" f"(cycle_id={body.cycle_id}, version_id={body.version_id})")
      add_to_cycle_task = None
      if body.version_id is not None and body.cycle_id is not None:
          add_to_cycle_task = asyncio.create_task(zephyr_service.add_test_to_cycle(
              issue_id=issue_id,
              project_id=PROJECT_ID,
              cycle_id=body.cycle_id,
              folder_id=None,
              version_id=body.version_id
          ))
      print(f"Add to cycle task created: {add_to_cycle_task is not None}")
      # Run (2) & (3) in parallel (whatever exists)
      print("Waiting for async tasks to complete...")
      exec_id = None
      if add_steps_task and add_to_cycle_task:
          steps_res, add_cycle_res = await asyncio.gather(add_steps_task, add_to_cycle_task)
          exec_id = (add_cycle_res or {}).get("execution_id")
      elif add_steps_task:
          await add_steps_task
      elif add_to_cycle_task:
          add_cycle_res = await add_to_cycle_task
          exec_id = (add_cycle_res or {}).get("execution_id")
      print(f"Async tasks completed. Execution ID: {exec_id}")
      # 4) If we have an execution AND user asked for a status → execute it
      print(f"Setting execution status if needed (exec_id={exec_id}), body.execution_status={body.execution_status}")
      if exec_id and body.execution_status:
          status_id = body.execution_status.get("id")
          await zephyr_service.execute_test(
                  project_id=PROJECT_ID,
                  issue_id=int(issue_id),
                  execution_id=str(exec_id),
                  status_id=int(status_id)
          )
      print(f"Set execution {exec_id} status to {status_id}")
      return {
          "jira": {"id": issue_id, "key": issue_key},
          "execution_id": exec_id
      }

    except HTTPException:
      raise
    except Exception as e:
      raise HTTPException(status_code=502, detail=f"Full create failed: {e}")

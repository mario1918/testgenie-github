from fastapi import APIRouter, HTTPException, Query, Path
from typing import List, Optional
from app.models.zephyr import (
    ExecuteBody, ZephyrTestCase, ZephyrTestCaseCreate, ZephyrTestCaseUpdate,
    ZephyrTestCaseWithSteps, ZephyrTestCaseCreateRequest,
    ZephyrTestCaseResponse, ZephyrBulkOperationResponse, AddTestStepsResponse, AddTestStepsBody, StepIn, AddToCycleResponse, AddToCycleBody, CreateCycleBody
)
from app.services.zephyr_service import zephyr_service, PROJECT_ID
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/zephyr", tags=["zephyr"])

@router.get("/test-cases/{test_case_id}", response_model=ZephyrTestCaseWithSteps)
async def get_test_case(test_case_id: str):
    """Get a test case with its steps"""
    try:
        print(f"Fetching test case with ID: {test_case_id}")
        test_case = await zephyr_service.get_test_case(test_case_id)
        if not test_case:
            raise HTTPException(status_code=404, detail="Test case not found")
        return test_case
    except Exception as e:
        logger.error(f"Error in get_test_case endpoint: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch test case")

@router.post("/test-cases/{issue_id}/steps", response_model=AddTestStepsResponse)
async def add_zephyr_test_steps(
    issue_id: str = Path(..., description="Jira issueId of the Test (numeric id)"),
    body: AddTestStepsBody = ...,
    ):
    """
    Add Zephyr Squad steps (and expected results) to a Test.
    - POST /public/rest/api/{api_version}/teststep/{issueId}?projectId=...
    """
    if not body.steps:
        raise HTTPException(status_code=400, detail="Steps list cannot be empty.")

    # Convert Pydantic models to the dict shape expected by the service
    steps_payload = [s.model_dump() for s in body.steps]

    try:
        res = await zephyr_service.add_test_steps(
            issue_id=issue_id,
            project_id=PROJECT_ID,
            steps=steps_payload
        )
        return AddTestStepsResponse(
            issue_id=str(issue_id),
            project_id=PROJECT_ID,
            steps_created=res.get("steps_created", 0),
            created_ids=res.get("created_ids", []),
            errors=res.get("errors", []),
        )
    except Exception as e:
        # Log as needed; keep response concise
        raise HTTPException(status_code=502, detail=f"Failed to add steps: {e}")

@router.get("/cycles")
async def list_cycles(
    version_id: int = Query(-1, description="Jira versionId; use -1 for Unscheduled"),
    offset: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=500),
    query: Optional[str] = Query(None, description="Filter by name/text (search endpoint only)"),
    ):
    """
    If version_id == -1 → use classic list.
    Else → use search endpoint.
    """
    try:
        return await zephyr_service.get_test_cycles(
                project_id=PROJECT_ID, version_id=version_id, offset=offset, limit=limit, query=query
        )
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Failed to fetch cycles: {e}")
    
@router.post("/cycles")
async def create_cycle(body: CreateCycleBody):
    """
    Create a Zephyr test cycle under the given version.
    Returns: {"id": <cycleId>, "raw": {...}}
    """
    try:
        return await zephyr_service.create_cycle(**body.model_dump())
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Failed to create cycle: {e}")

@router.get("/execution-status")
async def get_execution_status_id():
    """
    Resolve a Zephyr execution status 
    Returns: {"name": "...", "id": <int>}
    """
    try:
        # Fetch all statuses
        data=await zephyr_service.get_execution_statuses()
        return data
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Failed to resolve status id: {e}")

@router.post("/test-cases/{issue_id}/cycle", response_model=AddToCycleResponse)
async def add_test_to_cycle(
    issue_id: str = Path(..., description="Jira issueId (numeric) of the Test"),
    body: AddToCycleBody = ...,
    ):
    """
    Create (or fetch existing) execution for the Test in the given Zephyr cycle.
    """
    try:
        res = await zephyr_service.add_test_to_cycle(
            issue_id=issue_id,
            project_id=PROJECT_ID,
            cycle_id=body.cycle_id,
            version_id=body.version_id,
            folder_id=body.folder_id,
        )
        return AddToCycleResponse(
            issue_id=str(issue_id),
            project_id=PROJECT_ID,
            cycle_id=body.cycle_id,
            version_id=body.version_id,
            execution_id=res.get("execution_id"),
            created=res.get("created", False),
            error=res.get("error"),
        )
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Failed to add test to cycle: {e}")

@router.put("/executions/{execution_id}")
async def execute_test_route(
    execution_id: str = Path(..., description="Zephyr execution ID (UUID or string)"),
    issue_id: int = Query(..., description="Jira issue ID (numeric) of the Test"),
    body: ExecuteBody = ...,
):
    """
    Set execution status.
    - Resolves status name -> id if needed.
    - Sends projectId/issueId as query params (for QSH), optional cycle/version in body.
    """
    try:
        # resolve status id
        if body.status_id is not None:
            status_id = body.status_id
            status_name = body.status or "<by-id>"
        else:
            raise HTTPException(status_code=400, detail="'status_id' must be provided.")

        await zephyr_service.execute_test(
            project_id=PROJECT_ID,
            issue_id=issue_id,
            execution_id=execution_id,
            status_id=status_id,
            cycle_id=body.cycle_id,
            version_id=body.version_id,
        )

        return {
            "ok": True,
            "execution_id": execution_id,
            "issue_id": issue_id,
            "status": status_name,
            "status_id": status_id,
            "cycle_id": body.cycle_id,
            "version_id": body.version_id,
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Failed to execute test: {e}")

@router.get("/executions")
async def get_executions(
        issue_id: int = Query(..., description="Jira numeric issueId for the Test"),
        cycle_id: Optional[int] = Query(None, description="Optional cycle to filter (use -1 for Ad hoc)"),
    ):
        """
        Returns executions for a Test. Empty 'items' means: not added to any cycle (no execution).
        """
        try:
            items = await zephyr_service.list_executions(issue_id=issue_id, project_id=PROJECT_ID, cycle_id=cycle_id)
            return {"count": len(items), "items": items}
        except Exception as e:
            raise HTTPException(status_code=502, detail=f"Failed to fetch executions: {e}")  
          
@router.get("/health")
async def zephyr_health_check():
    try:
        res = await zephyr_service.get_test_cases(project_id=PROJECT_ID, max_results=1)
        return {
            "status": "healthy",
            "zephyr_accessible": True,
            "test_cases_accessible": True,
            "sample_count": res.get("total", 0)
        }
    except Exception as e:
        logger.error(f"Zephyr health check failed: {e}")
        return {"status": "unhealthy", "zephyr_accessible": False, "error": str(e)}

